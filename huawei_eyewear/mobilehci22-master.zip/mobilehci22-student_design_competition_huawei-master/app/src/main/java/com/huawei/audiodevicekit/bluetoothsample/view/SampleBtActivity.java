package com.huawei.audiodevicekit.bluetoothsample.view;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.huawei.audiobluetooth.api.Cmd;
import com.huawei.audiobluetooth.api.data.SensorData;
import com.huawei.audiobluetooth.layer.protocol.mbb.DeviceInfo;
import com.huawei.audiobluetooth.utils.DateUtils;
import com.huawei.audiobluetooth.utils.LocaleUtils;
import com.huawei.audiobluetooth.utils.LogUtils;
import com.huawei.audiodevicekit.R;
import com.huawei.audiodevicekit.bluetoothsample.contract.SampleBtContract;
import com.huawei.audiodevicekit.bluetoothsample.presenter.SampleBtPresenter;
import com.huawei.audiodevicekit.bluetoothsample.view.adapter.SingleChoiceAdapter;
import com.huawei.audiodevicekit.mvp.view.support.BaseAppCompatActivity;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SampleBtActivity
        extends BaseAppCompatActivity<SampleBtContract.Presenter, SampleBtContract.View>
        implements SampleBtContract.View {
    private static final String TAG = "SampleBtActivity";
    private static String User = "None";

    private TextView tvDevice;

    private TextView tvStatus;

    private ListView listView;

    private TextView tvSendCmdResult;

    private Button btnSearch;

    private Button btnConnect;

    private Button btnDisconnect;

    private Spinner spinner;

    private Button btnSendCmd;

    private RecyclerView rvFoundDevice;

    private SingleChoiceAdapter mAdapter;

    private Cmd mATCmd = Cmd.VERSION;

    private String mMac;

    private List<Map<String, String>> maps;

    private SimpleAdapter simpleAdapter;

    private TextView tvDataCount;

    ////////

    private CheckBox check_al;
    private CheckBox check_st;
    private CheckBox check_je;

    private static CheckBox set_overall;
    private static EditText activity_tb;
    private static Long timestamp;
    private static int min_length;
    private TextToSpeech textToSpeechSystem;

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public SampleBtContract.Presenter createPresenter() {
        return new SampleBtPresenter();
    }

    @Override
    public SampleBtContract.View getUiImplement() {
        return this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, 1);
        }

    }

    @Override
    protected int getResId() {
        return R.layout.activity_main;
    }

    @Override
    protected void initView() {
        tvDevice = findViewById(R.id.tv_device);
        tvStatus = findViewById(R.id.tv_status);
        tvDataCount = findViewById(R.id.tv_data_count);
        listView = findViewById(R.id.listview);
        tvSendCmdResult = findViewById(R.id.tv_send_cmd_result);
        btnSearch = findViewById(R.id.btn_search);
        btnConnect = findViewById(R.id.btn_connect);
        btnDisconnect = findViewById(R.id.btn_disconnect);
        spinner = findViewById(R.id.spinner);
        btnSendCmd = findViewById(R.id.btn_send_cmd);
        rvFoundDevice = findViewById(R.id.found_device);
        check_al = findViewById(R.id.usr_al);  ///
        check_st = findViewById(R.id.usr_st);  ///
        check_je = findViewById(R.id.usr_je);
        set_overall = findViewById(R.id.setting_overall); ///
        activity_tb = findViewById(R.id.activity_textbox); ///
        initSpinner();
        initRecyclerView();
        maps = new ArrayList<>();
        simpleAdapter = new SimpleAdapter(this, maps, android.R.layout.simple_list_item_1,
                new String[]{"data"}, new int[]{android.R.id.text1});
        listView.setAdapter(simpleAdapter);

        textToSpeechSystem = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = textToSpeechSystem.setLanguage(Locale.US);
                }
            }
        });
    }

    private void initSpinner() {
        List<Map<String, String>> data = new ArrayList<>();
        for (Cmd cmd : Cmd.values()) {
            if (cmd.isEnable()) {
                HashMap<String, String> map = new HashMap<>();
                Boolean isChinese = LocaleUtils.isChinese(this);
                String name = isChinese ? cmd.getNameCN() : cmd.getName();
                map.put("title", cmd.getType() + "-" + name);
                data.add(map);
            }
        }
        spinner.setAdapter(
                new SimpleAdapter(this, data, R.layout.item_spinner, new String[]{"title"},
                        new int[]{R.id.tv_name}));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                LogUtils.i(TAG, "onItemSelected position = " + position);
                String title = data.get(position).get("title");
                String type = Objects.requireNonNull(title).split("-")[0];
                try {
                    int typeValue = Integer.parseInt(type);
                    mATCmd = Cmd.getATCmdByType(typeValue);
                } catch (NumberFormatException e) {
                    LogUtils.e(TAG, "parseInt fail e = " + e);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                LogUtils.i(TAG, "onNothingSelected parent = " + parent);
            }
        });
    }

    private void initRecyclerView() {
        SingleChoiceAdapter.SaveOptionListener mOptionListener = new SingleChoiceAdapter.SaveOptionListener() {
            @Override
            public void saveOption(String optionText, int pos) {
                LogUtils.i(TAG, "saveOption optionText = " + optionText + ",pos = " + pos);
                mMac = optionText.substring(1, 18);
                boolean connected = getPresenter().isConnected(mMac);
                if (connected) {
                    getPresenter().disConnect(mMac);
                } else {
                    getPresenter().connect(mMac);
                }
            }

            @Override
            public void longClickOption(String optionText, int pos) {
                LogUtils.i(TAG, "longClickOption optionText = " + optionText + ",pos = " + pos);
            }
        };
        mAdapter = new SingleChoiceAdapter(this, new ArrayList<>());
        mAdapter.setSaveOptionListener(mOptionListener);
        rvFoundDevice.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        rvFoundDevice.setAdapter(mAdapter);
    }

    @Override
    protected void initData() {
        getPresenter().initBluetooth(this);
    }

    @Override
    protected void setOnclick() {
        super.setOnclick();

        btnConnect.setOnClickListener(v -> getPresenter().connect(mMac));
        btnDisconnect.setOnClickListener(v -> getPresenter().disConnect(mMac));
        btnSearch.setOnClickListener(v -> getPresenter().checkLocationPermission(this));
        btnSendCmd.setOnClickListener(v -> {
            getPresenter().sendCmd(mMac, mATCmd.getType());
            // extended code to add duration timer for option 19 - enable sensor reporting
            if (mATCmd.getType() == 19) {
                timestamp = System.currentTimeMillis();
                runOnUiThread(() -> {
                    textToSpeechSystem.speak("Start recording", TextToSpeech.QUEUE_ADD, null);
                    new CountDownTimer(10000, 1000) {
                        @Override
                        public void onTick(long l) {

                        }

                        public void onFinish() {
                            getPresenter().sendCmd(mMac, 20);
                            textToSpeechSystem.speak("Stop recording", TextToSpeech.QUEUE_ADD, null);
                        }
                    }.start();

                });
            }
        });

        //some multiple checkbox selection prevention

        check_st.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (check_st.isChecked()) {
                    check_al.setEnabled(false);
                    check_je.setEnabled(false);
                    User = "Stefan";
                } else {
                    check_al.setEnabled(true);
                    check_je.setEnabled(true);
                    User = "None";
                }
            }
        });

        check_al.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (check_al.isChecked()) {
                    check_st.setEnabled(false);
                    check_je.setEnabled(false);
                    User = "Alper";
                } else {
                    check_st.setEnabled(true);
                    check_je.setEnabled(true);
                    User = "None";
                }
            }
        });

        check_je.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (check_je.isChecked()) {
                    check_al.setEnabled(false);
                    check_st.setEnabled(false);
                    User = "Jean-Luc";
                } else {
                    check_al.setEnabled(true);
                    check_st.setEnabled(true);
                    User = "None";
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        getPresenter().processLocationPermissionsResult(requestCode, grantResults);
    }

    @Override
    public void onDeviceFound(DeviceInfo info) {
        if (mAdapter == null) {
            return;
        }
        runOnUiThread(() -> mAdapter
                .pushData(String.format("[%s] %s", info.getDeviceBtMac(), "HUAWEI Eyewear")));
    }

    @Override
    public void onStartSearch() {
        if (mAdapter != null) {
            runOnUiThread(() -> mAdapter.clearData());
        }
    }

    @Override
    public void onDeviceChanged(BluetoothDevice device) {
        if (tvDevice != null) {
            runOnUiThread(() -> tvDevice
                    .setText(String.format("[%s] %s", device.getAddress(), "HUAWEI Eyewear")));
        }
    }

    @Override
    public void onConnectStateChanged(String stateInfo) {
        if (tvStatus != null) {
            runOnUiThread(() -> tvStatus.setText(stateInfo));
        }
    }

    @Override
    public void onSensorDataChanged(SensorData sensorData) {
        runOnUiThread(() -> {
            Map<String, String> map = new HashMap<>();
            map.put("data", sensorData.toString());
            // filter_sensor ist von mir
            filter_sensor(sensorData.toString());


            maps.add(0, map);
            tvDataCount.setText(getString(R.string.sensor_data, maps.size()));
            simpleAdapter.notifyDataSetChanged();
        });
    }

    @Override
    public void onSendCmdSuccess(Object result) {
        runOnUiThread(() -> {
            String info = DateUtils.getCurrentDate() + "\n" + result.toString();
            tvSendCmdResult.setText(info);

        });
    }

    @Override
    public void onError(String errorMsg) {
        runOnUiThread(
                () -> Toast.makeText(SampleBtActivity.this, errorMsg, Toast.LENGTH_LONG).show());
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        getPresenter().deInit();
    }

    public void filter_sensor(String sensordata) {
        String output_without_beginning_and_end = null;
        String[] title_and_content_buff = null;
        List<String> titles = new ArrayList<String>();
        List<String> content = new ArrayList<String>();
        List<String> titles_accel = new ArrayList<String>();
        List<String> content_accel = new LinkedList<String>();
        List<String> content_gyro = new LinkedList<String>();


        /// identification of accelDataLen value, to skip empty reportings

        String pattern = "accelDataLen=(\\d*),";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(sensordata);
        m.find();
        String regex_result_accel = m.group(1);


        /// identification of accelDataLen value. In case if one DataLen value is bigger then, reduce the other to the same size, so we don't have accel data without gyro data or vice versa

        String pattern_gyro = "gyroDataLen=(\\d*),";
        Pattern r_gyro = Pattern.compile(pattern_gyro);
        Matcher m_gyro = r_gyro.matcher(sensordata);
        m_gyro.find();
        String regex_result_gyro = m_gyro.group(1);

        min_length = Math.min(Integer.parseInt(regex_result_accel), Integer.parseInt(regex_result_gyro));

        /// Cutting + Filtering Sesnordata

        if (!regex_result_accel.equals("0")) {
            output_without_beginning_and_end = sensordata.substring(11, sensordata.length() - 1);
            String[] overall_items = output_without_beginning_and_end.split("(?!<(?:\\(|\\[)[^)\\]]+),(?![^(\\[]+(?:\\)|\\]))"); // regex for finding all comma which are not in square brackets

            for (int i = 0; i < overall_items.length; i++) {
                title_and_content_buff = overall_items[i].split("(?!<\\(|\\{[^)\\}]+)=(?![^(\\[]+\\}|\\})"); //regex for "=" outside of "{}"
                titles.add(title_and_content_buff[0]);
                content.add(title_and_content_buff[1]);


                if (overall_items[i].contains("accelData") && !(overall_items[i].contains("accelDataLen"))) {
                    String output_without_beginning_and_end_2 = null;
                    output_without_beginning_and_end_2 = overall_items[i].substring(11, overall_items[i].length() - 1);
                    String[] accel_items = (output_without_beginning_and_end_2.split(",(?=[^}]*(?:\\{|$))")); //regex for splitting on each comma outside {}
                    Log.d("Accel_items", Arrays.toString(accel_items));
                    String buff = (((Arrays.toString(accel_items)).replaceAll(",", "")).replaceAll("[^\\d.\\- ]", "").replaceAll("  ", " "));
                    content_accel = Arrays.asList(buff.split(" "));
                }

                if (overall_items[i].contains("gyroData") && !(overall_items[i].contains("gyroDataLen"))) {
                    String output_without_beginning_and_end_3 = null;
                    output_without_beginning_and_end_3 = overall_items[i].substring(10, overall_items[i].length() - 1);
                    String[] gyro_items = output_without_beginning_and_end_3.split(",(?=[^}]*(?:\\{|$))"); //regex for splitting on each comma outside {}
                    Log.d("Gyro_items", Arrays.toString(gyro_items));
                    String buff = (((Arrays.toString(gyro_items)).replaceAll(",", "")).replaceAll("[^\\d.\\- ]", "").replaceAll("  ", " "));
                    System.out.println("GyroData: " + buff);
                    content_gyro = Arrays.asList(buff.split(" "));

                }
            }
            save_gyro_accel(content_accel, content_gyro, "accel_gyro");
            save_overall(titles, content, "overall");
        }
    }

    public static void save_overall(List<String> titles, List<String> content, String f_name) {

        if (f_name == "overall" && set_overall.isChecked()) {

            try {
                String ts = timestamp.toString();
                File filepath = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/" + ts + "_" + User + "_" + activity_tb.getText() + "_" + f_name + ".csv");
                Log.d("path", filepath.getPath());
                FileWriter csvWriter = new FileWriter(filepath, true);
                Iterator<String> titles_iterator = titles.iterator();
                Iterator<String> content_iterator = content.iterator();

                if (filepath.length() == 0) {                                            //check if first iteration, for header
                    while (titles_iterator.hasNext()) {
                        csvWriter.append((String) titles_iterator.next());
                        if (titles_iterator.hasNext() == true)
                            csvWriter.append(";");
                    }
                }
                csvWriter.append("\n");
                while (content_iterator.hasNext()) {
                    //String i = (String) titles_iterator.next();
                    csvWriter.append((String) content_iterator.next());
                    if (content_iterator.hasNext() == true)
                        csvWriter.append(";");
                }

                csvWriter.flush();
                csvWriter.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }

    }

    public static void save_gyro_accel(List<String> accel, List<String> gyro, String f_name) {

        if (f_name == "accel_gyro") {

            try {
                String ts = timestamp.toString();
                File filepath = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/" + ts + "_" + User + "_" + activity_tb.getText() + "_" + f_name + ".csv");
                Log.d("path", filepath.getPath());
                FileWriter csvWriter = new FileWriter(filepath, true);
                Iterator<String> content_iterator_accel = accel.iterator();
                Iterator<String> content_iterator_gyro = gyro.iterator();

                if (filepath.length() == 0) {                                           //check if first iteration, for header
                    csvWriter.append("Accel_X");
                    csvWriter.append(";");
                    csvWriter.append("Accel_Y");
                    csvWriter.append(";");
                    csvWriter.append("Accel_Z");
                    csvWriter.append(";");
                    csvWriter.append("roll");
                    csvWriter.append(";");
                    csvWriter.append("pitch");
                    csvWriter.append(";");
                    csvWriter.append("yaw");
                    csvWriter.append("\n");
                    ;
                }

                int i = 0;
                int j = 0;
                while (content_iterator_accel.hasNext()) {

                    String next_value_accel = (String) content_iterator_accel.next();


                    csvWriter.append(next_value_accel);
                    i++;

                    if (i % 3 == 0) {
                        csvWriter.append(";");
                        while (content_iterator_gyro.hasNext()) {
                            String next_value_gyro = (String) content_iterator_gyro.next();
                            csvWriter.append(next_value_gyro);
                            j++;
                            if (j % 3 == 0) {
                                csvWriter.append("\n");
                                break;
                            } else csvWriter.append(";");
                        }
                    } else csvWriter.append(";");

                    if ((i % (min_length * 3) == 0) && (i != 0)) {
                        i = 0;
                        break;

                    }

                }

                csvWriter.flush();
                csvWriter.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }

    }

}
